﻿namespace RelicviaShope.Models;

public class Admin : User
{

}
